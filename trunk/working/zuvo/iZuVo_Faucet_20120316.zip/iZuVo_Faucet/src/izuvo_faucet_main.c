/*******************************************************************************

*******************************************************************************/

#include "izuvo_faucet_main.h"
#include "utility.h"

unsigned char mTx_Busy;			// TX Flag


/*****************************************************************************
******************************************************************************/

void delayms(unsigned char ms)
{
	unsigned int i;
	while(ms--)
	{
		for(i = 0; i < 2000; i++)
		{
			_nop_();
		}
	}
}

/*****************************************************************************


******************************************************************************/
 main()
{
	unsigned char LED;
	P1M0 = 0xff;
	P1M1 = 0x00;
	LED = 0x03;
	LED |= 0x04;	// Red
	LED |= 0x08;	// Common Anode
//	LED |= 0x10;	// Blue
//	LED |= 0x20;	// Green
	P1 = LED;

//	Init UART
	SCON = 0x50;				// 8-bits UART No parity
	TL2  = RCAP2L = (65536-(FOSC/32/BAUD));
	TH2  = RCAP2H = (65536-(FOSC/32/BAUD)) >> 8;
	T2CON = 0x34;
//	ES	 = 1;					// Enable UART interrupt

	u_puts(VERSION);

//	EA		= 1;				// Enable Global Interrupt

	while(1)
	{
		delayms(250);
		LED ^= 0x02 ;		
		P1  = LED;
		u_putch('A');
//		u_puts("Hello\r\n");
	}
}
