#include<reg52.h>
#include <intrins.h>
//#include "stc_mcu.h"

// STC register

sfr P1M1 = 0x91;
sfr P1M0 = 0x92;
sfr P0M1 = 0x93;
sfr P0M0 = 0x94;

#define VERSION "iZuVo_Faucet 1.0 @ " __DATE__ "  " __TIME__ "\r\n"

#define FOSC 11080373L
#define BAUD 115200

#define T1MS (65536 - FOSC/12/1000)
#define T500US (65535 - (51+(256*7)))
